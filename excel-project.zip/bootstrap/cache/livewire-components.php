<?php return array (
  'select-category' => 'App\\Http\\Livewire\\SelectCategory',
);